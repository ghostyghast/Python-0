def bye() -> None:
    print("Bye >:)")
