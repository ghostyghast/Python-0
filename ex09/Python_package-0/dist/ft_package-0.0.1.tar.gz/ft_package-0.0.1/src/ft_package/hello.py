def hello() -> None:
    print("hello :)")
