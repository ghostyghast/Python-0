def cat() -> None:
    print("\\    /\\\n )  ( ')\n(  /  )\n \\(__)|\n")
